console.log("✅ 360 AI Me client loaded");
const chatBox=document.getElementById("chat-box");
const userInput=document.getElementById("user-input");
const sendBtn=document.getElementById("send-btn");
function addMessage(text,sender){
  const el=document.createElement("div");
  el.classList.add("message",sender);
  el.textContent=text;
  chatBox.appendChild(el);
  chatBox.scrollTop=chatBox.scrollHeight;
  return el;
}
async function sendMessage(){
  const text=userInput.value.trim();
  if(!text)return;
  addMessage("🧑 "+text,"user");
  userInput.value="";
  const aiEl=addMessage("🤖 Thinking...","ai");
  let dots=0;
  const t=setInterval(()=>{aiEl.textContent="🤖 Thinking"+".".repeat(dots%4);dots++;},400);
  try{
    const resp=await fetch("/chat",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:text})
    });
    clearInterval(t);
    if(!resp.ok){
      aiEl.textContent=`⚠️ Server error: ${resp.status}`;
      return;
    }
    const j=await resp.json();
    if(j.error){aiEl.textContent="⚠️ "+j.error;return;}
    const reply=j.reply||JSON.stringify(j);
    aiEl.textContent="🤖 "+reply;
    chatBox.scrollTop=chatBox.scrollHeight;
  }catch(err){
    clearInterval(t);
    aiEl.textContent="⚠️ Network or API error, please try again.";
    console.error("Fetch error:",err);
  }
}
sendBtn.addEventListener("click",sendMessage);
userInput.addEventListener("keypress",e=>{if(e.key==="Enter")sendMessage();});
