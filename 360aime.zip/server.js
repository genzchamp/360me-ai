// server.js - Express proxy for Hugging Face router API
const express = require("express");
const fetch = require("node-fetch");
const path = require("path");
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const HF_MODEL_FALCON = "https://router.huggingface.co/hf-inference/models/tiiuae/falcon-7b-instruct";
const HF_MODEL_FLAN = "https://router.huggingface.co/hf-inference/models/google/flan-t5-base";

const HF_API_TOKEN = process.env.HF_API_TOKEN || "";

if (!HF_API_TOKEN) {
  console.warn("⚠️ HF_API_TOKEN not set in environment. Please add it to Replit Secrets.");
}

async function callHf(modelUrl, message) {
  const response = await fetch(modelUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${HF_API_TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      inputs: message,
      parameters: { max_new_tokens: 200 }
    })
  });
  const data = await response.json();
  return { status: response.status, data };
}

app.post("/chat", async (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: "No message provided" });

  try {
    let result = await callHf(HF_MODEL_FALCON, message);
    if (result.data?.error || result.status >= 400 || result.data === null) {
      console.log("Falcon error:", result.status, result.data?.error || result.data);
      result = await callHf(HF_MODEL_FLAN, message);
    }

    const d = result.data;
    if (Array.isArray(d) && d[0]?.generated_text) return res.json({ reply: d[0].generated_text });
    if (d?.generated_text) return res.json({ reply: d.generated_text });
    if (d?.error) return res.json({ error: d.error });
    return res.json({ reply: JSON.stringify(d) });
  } catch (err) {
    console.error("Proxy server error:", err);
    return res.status(500).json({ error: err.message || "Server error" });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`✅ 360 AI Me server running on port ${port}`));
